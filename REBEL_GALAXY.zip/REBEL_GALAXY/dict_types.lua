local dict = {
   -1, "ANOT_VALID",    -- ???
    0, "NOT_SET",       -- ???
    1, "INTEGER",
    2, "FLOAT",
  --3, "???",
  --4, "???",
    5, "STRING",
    6, "BOOL",
    7, "INT64",
    8, "TRANSLATE",     -- ???
  --x, "VECTOR2",
  --x, "VECTOR3",
  --x, "VECTOR4",
  --x, "UNSIGNED INTEGER",
  --x, "DOUBLE",
  --x, "NOTE",
  --x, "WSTRING",
}

return dict
